#' This is data to be included in my package
#'
#' @name defaultTimeSeries
#' @docType data
#' @author My Name \email{dent.lucas@gmail.com}
#' @references \url{github.com\somaSystems\lifeTimes}
#' @keywords data
NULL
